# struktuR
This repository contains R code for the package struktuR used for estimation in struktur statistics at Statistics Norway. This is a R development, based on the SAS application used for many statistics called Struktur.
