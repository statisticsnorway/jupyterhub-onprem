## ---- include = FALSE---------------------------------------------------------
options(rmarkdown.html_vignette.check_title = FALSE)
library(knitr)
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----install, eval=FALSE------------------------------------------------------
#  devtools::install_github("statisticsnorway/struktuR")

## -----------------------------------------------------------------------------
library(struktuR)

## ---- eval = F----------------------------------------------------------------
#  head(pop_data)

## ---- echo = F----------------------------------------------------------------
kable(head(pop_data))

## ---- eval = F----------------------------------------------------------------
#  head(sample_data)

## ---- echo = F----------------------------------------------------------------
kable(head(sample_data))

## ---- echo = FALSE, fig.height=3, fig.width=6---------------------------------
library(ggplot2)
set.seed(2022)
residdata <- data.frame(x = runif(50)*100)
residdata$y = residdata$x * 10 + residdata$x * runif(50, min = -5, max = 5)
ggplot(residdata, aes(x, y)) + 
  geom_point() +
  geom_smooth(method='lm', formula='y~x-1', se = FALSE)


## ---- message=FALSE, eval = F-------------------------------------------------
#  results <- struktur_model(pop_data, sample_data,
#                            x = "employees",
#                            y = "job_vacancies",
#                            id = "id",
#                            strata = "industry")
#  head(results)

## ---- message=FALSE, echo = F-------------------------------------------------
results <- struktur_model(pop_data, sample_data, 
                          x = "employees", 
                          y = "job_vacancies", 
                          id = "id",
                          strata = "industry")
kable(head(results))

## ---- eval = F----------------------------------------------------------------
#  results_table <- get_results(results)
#  results_table

## ---- echo = F----------------------------------------------------------------
results_table = get_results(results)
kable(head(results_table))

## ---- eval = F----------------------------------------------------------------
#  results$country <- 1
#  get_results(results, group = c("country", "industry"))

## ---- echo = F----------------------------------------------------------------
results$country <- 1
gg <- get_results(results, group = c("country", "industry"))
kable(gg)

## ---- eval = F----------------------------------------------------------------
#  outliers <- get_extremes(data = results)
#  head(outliers)

## ---- echo = F----------------------------------------------------------------
outliers <- get_extremes(results)
kable(head(outliers))

## -----------------------------------------------------------------------------
plot_extreme(outliers)

## ---- fig.width = 7, eval = T-------------------------------------------------
plot_extreme(outliers, type = "G")

