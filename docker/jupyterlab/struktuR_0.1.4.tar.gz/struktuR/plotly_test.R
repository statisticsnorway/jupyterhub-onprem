# plotly test
data(sample_data)
data(pop_data)


library(plotly)
library(struktuR)

fig <- plot_ly(data, x = ~Women, y = ~Men, text = ~School, type = 'scatter', mode = 'markers',
               marker = list(size = ~Gap, opacity = 0.5))

# run results
results <- struktur_model(pop_data, sample_data, 
                              x = "employees", 
                              y = "job_vacancies", 
                              id = "id", strata = "industry")

#results <- get_results(pop_results, x = "x", y = "y", strata = "stratum")
#groups <- get_groups(pop_results, x = "x", y = "y", strata = "stratum", group = c("grp3", "grp4"))
diffts <- get_extremes(data = results, id = "id", x = "employees", y = "job_vacancies", strata = "industry")

results_samp <- results[!is.na(results$job_vacancies), ]
fig <- plot_ly(results_samp, x = ~employees, y = ~job_vacancies, 
               hoverinfo = 'text',
               text = ~paste('ID:', id, '<br>G-verdi:', job_vacancies_G),
               color = ~industry,
               type = 'scatter', mode = 'markers',
               marker = list(size = ~job_vacancies_G*20, opacity = 0.5))
fig

fig2 <- plot_ly(results_samp, x = ~job_vacancies, y = ~job_vacancies_imp, 
               hoverinfo = 'text',
               text = ~paste('ID:', id, '<br>G-verdi:', job_vacancies_G),
               color = ~industry,
               type = 'scatter', mode = 'markers',
               marker = list(size = ~job_vacancies_G*20, opacity = 0.5))
fig2
