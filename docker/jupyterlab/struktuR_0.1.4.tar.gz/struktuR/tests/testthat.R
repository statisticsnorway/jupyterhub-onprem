library(testthat)
library(struktuR)

test_check("struktuR")
